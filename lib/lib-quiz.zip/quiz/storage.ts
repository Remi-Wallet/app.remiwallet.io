// lib/quiz/storage.ts
export type Tier = "A" | "B" | "C";
export type Answers = Record<string, any>;
export type QuizState = { answers: Answers; tier?: Tier };

export const QUIZ_STATE_KEY = "remi_quiz_state";
export const SESSION_ID_KEY = "remi_session_id";
export const TIER_KEY = "remi_tier";

export function getOrCreateSessionId() {
  try {
    const existing = localStorage.getItem(SESSION_ID_KEY);
    if (existing) return existing;
    const id = crypto.randomUUID();
    localStorage.setItem(SESSION_ID_KEY, id);
    return id;
  } catch {
    // fallback (very rare)
    const id = `sess_${Date.now()}`;
    try { localStorage.setItem(SESSION_ID_KEY, id); } catch {}
    return id;
  }
}

export function loadQuizState(): QuizState {
  try {
    const raw = localStorage.getItem(QUIZ_STATE_KEY);
    if (!raw) return { answers: {} };
    const parsed = JSON.parse(raw);
    return { answers: parsed?.answers ?? {}, tier: parsed?.tier };
  } catch {
    return { answers: {} };
  }
}

export function saveQuizState(state: QuizState) {
  try {
    localStorage.setItem(QUIZ_STATE_KEY, JSON.stringify(state));
  } catch {}
}

export function saveAnswer(questionKey: string, value: any) {
  const state = loadQuizState();
  const next = { ...state, answers: { ...state.answers, [questionKey]: value } };
  saveQuizState(next);
  return next;
}

export function persistTier(tier: Tier) {
  try {
    localStorage.setItem(TIER_KEY, tier);
  } catch {}
  const state = loadQuizState();
  const next = { ...state, tier };
  saveQuizState(next);
  return next;
}

// --- Compatibility layer for older machine.ts imports ---
// This lets the build pass even if machine.ts isn't used yet.

export type StoredQuiz = {
  sessionId: string;
  answers: Answers; // <- assumes you already export type Answers in this file
  tier?: "A" | "B" | "C";
  updatedAt?: string;
};

const LS_STORED_QUIZ = "remi_quiz_stored_v1";

export function getStoredQuiz(): StoredQuiz | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LS_STORED_QUIZ);
    return raw ? (JSON.parse(raw) as StoredQuiz) : null;
  } catch {
    return null;
  }
}

export function setStoredQuiz(next: StoredQuiz): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(
    LS_STORED_QUIZ,
    JSON.stringify({ ...next, updatedAt: new Date().toISOString() })
  );
}