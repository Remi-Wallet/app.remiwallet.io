// lib/quiz/types.ts

export type Tier = "A" | "B" | "C";

export type QuizOption = {
  label: string;
  value: string;
  helperText?: string;
  icon?: string;
};